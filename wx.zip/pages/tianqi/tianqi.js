

Page({

  /**
   * 页面的初始数据
   */
  data: {
    UDTime:'',
    city: '',
    pre_temp: '',
    weather: '',
    weather_id: '',
    hum: '',
    aqi: '',
    wind: '',
    advice: '',
    temp:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.request({
      url: 'https://www.ccc425.cn/WeatherForecast',
      method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      // header: {}, // 设置请求的 header
      success: function (res) {
        that.setData({UDTime : res.data.UDTime});
        that.setData({city : res.data.city});
        that.setData({temp : res.data.temp})
        that.setData({pre_temp : res.data.pre_temp});
        that.setData({weather : res.data.weather});
        that.setData({weather_id : res.data.weather_id});
        that.setData({hum : res.data.hum});
        that.setData({aqi : res.data.aqi});
        that.setData({AT : res.data.AT});
        that.setData({wind: res.data.wind});
        that.setData({advice : res.data.advice});
        console.log(res.data)
      },
      fail: function () {
        console.log("Query failed")
      },
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})