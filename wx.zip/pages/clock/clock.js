const app = getApp();

Page({
  data: {
    items: [
      { name: 'Sun', value: '星期日' },
      { name: 'Mon', value: '星期一' },
      { name: 'Tue', value: '星期二' },
      { name: 'Wed', value: '星期三' },
      { name: 'Thu', value: '星期四' },
      { name: 'Fri', value: '星期五' },
      { name: 'Sat', value: '星期六' },
    ],
    hour:"00",
    minute:"00",
    weekly: [0, 0, 0, 0, 0, 0, 0],
    note:'',
    repeat:'',
    month:'',
    date:'',
    appoint:'',
    Au:0,
    m:'',
    d:'',
    S:[],
  },

  bindTimeChange: function (e) {
    var that = this;
    that.setData({
      time: e.detail.value,
      hour: String(e.detail.value[0]) + String(e.detail.value[1]),
      minute: String(e.detail.value[3]) + String(e.detail.value[4]),
    })
  },

  Anote:function(e){
    var that=this;
    that.setData({
      note: e.detail.value
    })
  },


  checkboxChange: function (e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value);
    var Weekly = [0, 0, 0, 0, 0, 0, 0] 
    for (var i = 0; i < e.detail.value.length; i++){
      var day;
      switch(e.detail.value[i]){
        case "Sun":
          day = 0;
          break;
        case "Mon":
          day = 1;
          break;
        case "Tue":
          day = 2;
          break;
        case "Wed":
          day = 3;
          break;
        case "Thu":
          day = 4;
          break;
        case "Fri":
          day = 5;
          break;
        case "Sat":
          day = 6;
          break;
      }
      Weekly[day] = 1;
    }
    this.setData({ weekly: Weekly });
  },

  //发送数据+储存
  store: function (e) {
    var that=this
    if(that.data.Au == 0){
      var n = 0;
      for (var i = 0; i < 7; i++) {
        if (that.data.weekly[i] === 0) {
          n = n + 1;
        }
      }
      if (n === 7) {
        that.setData({ repeat: 0 });
      }
      else {
        that.setData({ repeat: 1 });
      }
      console.log("form发生了Send事件，携带数据为：")
      wx.request({
        url: 'https://www.ccc425.cn/NewAlarm',
        method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
        // header: {}, // 设置请求的 header
        data: {
          hour: this.data.hour,
          minute: this.data.minute,
          weekly: JSON.stringify(this.data.weekly),
          note: JSON.stringify(this.data.note),
          repeat: JSON.stringify(this.data.repeat),
          month: JSON.stringify(0),
          date: JSON.stringify(0),
          appoint: JSON.stringify(0)
        },
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          var i = app.globalData.zu.length;
          that.setData({ zu: app.globalData.zu });
          let na;
          na = "zu[" + i + "].hour";
          that.setData({ [na]: that.data.hour });
          na = "zu[" + i + "].minute";
          that.setData({ [na]: that.data.minute });
          na = "zu[" + i + "].weekly";
          that.setData({ [na]: that.data.weekly });
          na = "zu[" + i + "]._id";
          that.setData({ [na]: res.data });
          na = "zu[" + i + "].repeat";
          that.setData({ [na]: that.data.repeat });
          na = "zu[" + i + "].appoint";
          that.setData({ [na]: 0 });
          na = "zu[" + i + "].month";
          that.setData({ [na]: 0 });
          na = "zu[" + i + "].date";
          that.setData({ [na]: 0 });
          na = "zu[" + i + "].note";
          that.setData({ [na]: that.data.note });
          app.globalData.zu = that.data.zu;
          wx.navigateBack({
            url: "../index/index"
          })
        },
        fail: function () {
          console.log("SendB failed")
        }
      })
    }
    else if(that.data.Au==1){
      if((that.data.m % 1 == 0)&&(that.data.m<13)&&(that.data.m>0)){
        if ((that.data.m == 1) || (that.data.m == 3) || (that.data.m == 5) || (that.data.m == 7) || (that.data.m == 8) || (that.data.m == 10) || (that.data.m == 12)){
          if((that.data.d<32)&&(that.data.d>0)&&(that.data.d %1==0)){
            wx.request({
              url: 'https://www.ccc425.cn/NewAlarm',
              method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
              // header: {}, // 设置请求的 header
              data: {
                hour: JSON.stringify(this.data.hour),
                minute: JSON.stringify(this.data.minute),
                weekly: JSON.stringify(this.data.weekly),
                note: JSON.stringify(this.data.note),
                repeat: JSON.stringify(this.data.repeat),
                month: JSON.stringify(this.data.m),
                date: JSON.stringify(this.data.d),
                appoint: JSON.stringify(1)
              },
              header: {
                'content-type': 'application/x-www-form-urlencoded'
              },
              success: function (res) {
                var i = app.globalData.zu.length;
                that.setData({ zu: app.globalData.zu });
                let na;
                na = "zu[" + i + "].hour";
                that.setData({ [na]: that.data.hour });
                na = "zu[" + i + "].minute";
                that.setData({ [na]: that.data.minute });
                na = "zu[" + i + "]._id";
                that.setData({ [na]: res.data });
                na = "zu[" + i + "].appoint";
                that.setData({ [na]: 1 });
                na = "zu[" + i + "].month";
                that.setData({ [na]: that.data.m });
                na = "zu[" + i + "].date";
                that.setData({ [na]: that.data.d });
                na = "zu[" + i + "].note";
                that.setData({ [na]: that.data.note });
                app.globalData.zu = that.data.zu;
                wx.navigateBack({
                  url: "../index/index"
                })
              },
              fail: function () {
                console.log("SendB failed")
              }
            })
          }
        }
        else if ((that.data.m == 4) || (that.data.m == 6) || (that.data.m == 9) || (that.data.m == 11)){
          if((that.data.d<31)&&(that.data.d>0)&&(that.data.d % 1 == 0)){
            wx.request({
              url: 'https://www.ccc425.cn/NewAlarm',
              method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
              // header: {}, // 设置请求的 header
              data: {
                hour: JSON.stringify(this.data.hour),
                minute: JSON.stringify(this.data.minute),
                note: JSON.stringify(this.data.note),
                month: JSON.stringify(this.data.m),
                date: JSON.stringify(this.data.d),
                appoint: JSON.stringify(1)
              },
              header: {
                'content-type': 'application/x-www-form-urlencoded'
              },
              success: function (res) {
                var i = app.globalData.zu.length;
                that.setData({ zu: app.globalData.zu });
                let na;
                na = "zu[" + i + "].hour";
                that.setData({ [na]: that.data.hour });
                na = "zu[" + i + "].minute";
                that.setData({ [na]: that.data.minute });
                na = "zu[" + i + "]._id";
                that.setData({ [na]: res.data });
                na = "zu[" + i + "].appoint";
                that.setData({ [na]: 1 });
                na = "zu[" + i + "].month";
                that.setData({ [na]: that.data.m });
                na = "zu[" + i + "].date";
                that.setData({ [na]: that.data.d });
                na = "zu[" + i + "].note";
                that.setData({ [na]: that.data.note });
                app.globalData.zu = that.data.zu;
                wx.navigateBack({
                  url: "../index/index"
                })
              },
              fail: function () {
                console.log("SendB failed")
              }
            })
          }
        }
        else{
          if((that.data.d<30)&&(that.data.d>0)&&(that.data.d%1==0)){
            wx.request({
              url: 'https://www.ccc425.cn/NewAlarm',
              method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
              // header: {}, // 设置请求的 header
              data: {
                hour: JSON.stringify(this.data.hour),
                minute: JSON.stringify(this.data.minute),
                note: JSON.stringify(this.data.note),
                month: JSON.stringify(this.data.m),
                date: JSON.stringify(this.data.d),
                appoint: JSON.stringify(1)
              },
              header: {
                'content-type': 'application/x-www-form-urlencoded'
              },
              success: function (res) {
                var i = app.globalData.zu.length;
                that.setData({ zu: app.globalData.zu });
                let na;
                na = "zu[" + i + "].hour";
                that.setData({ [na]: that.data.hour });
                na = "zu[" + i + "].minute";
                that.setData({ [na]: that.data.minute });
                na = "zu[" + i + "]._id";
                that.setData({ [na]: res.data });
                na = "zu[" + i + "].appoint";
                that.setData({ [na]: 1 });
                na = "zu[" + i + "].month";
                that.setData({ [na]: that.data.m });
                na = "zu[" + i + "].date";
                that.setData({ [na]: that.data.d });
                na = "zu[" + i + "].note";
                that.setData({ [na]: that.data.note });
                app.globalData.zu = that.data.zu;
                wx.navigateBack({
                  url: "../index/index"
                })
              },
              fail: function () {
                console.log("SendB failed")
              }
            })
          }
        }
      }
    }
    else{
      console.log(useless)
    }
    },


  changeSwitch:function(){
    var that = this;
    if(that.data.Au == 0){
      that.setData({Au:1});
    }
    else {
      that.setData({ Au: 0 });
    }
      console.log(that.data.Au)
    },



    month:function(){
      var that = this;
      that.setData({m:e.detail.value})
    },

    day: function () {
    var that = this;
    that.setData({ d: e.detail.value })
  }

})

