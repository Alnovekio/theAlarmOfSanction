const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    t:0,
    WU:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log("form发生了Load事件，携带数据为：")
    var that = this;
    wx.request({
      url: 'https://www.ccc425.cn/query',
      method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      // header: {}, // 设置请求的 header
      success: function (res) {
        app.globalData.zu = res.data.A;
        that.setData({zu: app.globalData.zu})
      },
      fail: function () {
        console.log("Query failed")
      },
    });
    //
    wx.request({
      url: 'https://www.ccc425.cn/WakeUp',
      method:'GET',
      success:function(res){
        if (res.data == 1) {
          wx.navigateTo({
            url: '../wakeup/wakeup',
          })
        }
        console.log(res);
      },
      fail:function(){
        console.log("Don't want to wake up")
      }
    });

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({zu:app.globalData.zu});
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  },
//跳转
  addItem: function (e) {
        wx.navigateTo({
    url: '../clock/clock',
  })
  },

  removeItem: function (e) {
    console.log("发生remove事件")
    if (this.data.t == 1) {
      this.setData({ t: 0 });
    }
    else {
      this.setData({ t: 1 });
    }
  },

  del: function (e) {
    console.log(e.target.id);
    var that = this;
    wx.request({
      url: 'https://www.ccc425.cn/delete',
      method: 'POST',
      data: {
        _id: app.globalData.zu[Number(e.target.id)]._id
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log("Got it!");
      },
      fail: function () {
        console.log("Failed")
      }
    })
    var zu = app.globalData.zu
    zu.splice(e.target.id, 1)
    that.setData({
      zu: zu
    })
    console.log("删除成功");
  },

  mod:function(e){
    console.log(e.target.id);
    app.globalData.id = e.target.id
    wx.navigateTo({
      url: '../part/part',
    })
  },

  plus: function () {
    if (this.data.isPopping) {
      this.popp();
      this.setData({
        isPopping: false
      })
    } else if (!this.data.isPopping) {
      this.takeback();
      this.setData({
        isPopping: true
      })
    }
  },

  popp: function () {
    var animationPlus = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease-out'
    })

    var animationcollect = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease-out'
    })
    var animationInput = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease-out'
    })
    animationPlus.rotateZ(180).step();
    animationcollect.translate(-100, -75).rotateZ(180).opacity(1).step();
    animationInput.translate(-100, 75).rotateZ(180).opacity(1).step();
    this.setData({
      animPlus: animationPlus.export(),
      animCollect: animationcollect.export(),
      animInput: animationInput.export(),
    })
  },
  takeback: function () {
    var animationPlus = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease-out'
    })
    var animationcollect = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease-out'
    })
    var animationInput = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease-out'
    })
    animationPlus.rotateZ(0).step();
    animationcollect.translate(0, 0).rotateZ(0).opacity(0).step();
    animationInput.translate(0, 0).rotateZ(0).opacity(0).step();
    this.setData({
      animPlus: animationPlus.export(),
      animCollect: animationcollect.export(),
      animInput: animationInput.export(),
    })
  },
})