// pages/part/part.js
const app = getApp();

Page({
    data: {
      items: [
        { name: 'Sun', value: '星期日' },
        { name: 'Mon', value: '星期一' },
        { name: 'Tue', value: '星期二' },
        { name: 'Wed', value: '星期三' },
        { name: 'Thu', value: '星期四' },
        { name: 'Fri', value: '星期五' },
        { name: 'Sat', value: '星期六' },
      ],
      hour:"",
      minute:"",
      weekly:[],
      note:"",
      month:"",
      date:"",
      repeat:"",
      appoint:"",
      _id:"",
     },

  bindTimeChange: function (e) {
    var that = this;
    that.setData({
      time: e.detail.value,
      hour: e.detail.value[0] + e.detail.value[1],
      minute: e.detail.value[3] + e.detail.value[4],
    })
  },

  Anote: function (e) {
    var that = this;
    if (e.detail.value == " ") {
      that.setData({
        note: app.globalData.zu[Number(app.globalData.id)].note,
      })
     }
     else {
      that.setData({
        note: e.detail.value,
      })
     }

  },

  checkboxChange: function (e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value);
    var Weekly = [0, 0, 0, 0, 0, 0, 0]
    for (var i = 0; i < e.detail.value.length; i++) {
      var day;
      switch (e.detail.value[i]) {
        case "Sun":
          day = 0;
          break;
        case "Mon":
          day = 1;
          break;
        case "Tue":
          day = 2;
          break;
        case "Wed":
          day = 3;
          break;
        case "Thu":
          day = 4;
          break;
        case "Fri":
          day = 5;
          break;
        case "Sat":
          day = 6;
          break;
      }
      Weekly[day] = 1;
    }
    this.setData({ weekly: Weekly });
  },

  

  //发送数据+储存
  store: function (e) {
    var that = this
    var n = 0;
    for (var i = 0; i < 7; i++) {
      if (that.data.weekly[i] === 0) {
        n = n + 1;
      }
    }
    if (n == 7) {
      that.setData({ repeat: 0 });
    }
    else {
      that.setData({ repeat: 1 });
    }
    console.log(this.data._id)
    wx.request({
      url: 'https://www.ccc425.cn/AlarmUpdate',
      method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      // header: {}, // 设置请求的 header
      data: {
        hour:this.data.hour,
        minute:this.data.minute,
        weekly:this.data.weekly,
        note:this.data.note,
        repeat:this.data.repeat,
        month:0,
        date:0,
        appoint:0,
        _id: this.data._id
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        var i = Number(app.globalData.id);
        that.setData({ zu: app.globalData.zu });
        let na;
        na = "zu[" + i + "].hour";
        that.setData({ [na]: that.data.hour });
        na = "zu[" + i + "].minute";
        that.setData({ [na]: that.data.minute });
        na = "zu[" + i + "].weekly";
        that.setData({ [na]: that.data.weekly });
        na = "zu[" + i + "].repeat";
        that.setData({ [na]: that.data.repeat });
        na = "zu[" + i + "].appoint";
        that.setData({ [na]: 0 });
        na = "zu[" + i + "].month";
        that.setData({ [na]: 0 });
        na = "zu[" + i + "].date";
        that.setData({ [na]: 0 });
        na = "zu[" + i + "].note";
        that.setData({ [na]: that.data.note });
        app.globalData.zu = that.data.zu;
        wx.navigateBack({
          url: "../index/index"
        })
      },
      fail: function () {
        console.log("SendB failed")
      }
    })
  },



  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    let na;
    that.setData({
      time:app.globalData.zu[Number(app.globalData.id)].hour + ":" + app.globalData.zu[Number(app.globalData.id)].minute,
      hour: app.globalData.zu[Number(app.globalData.id)].hour,
      minute: app.globalData.zu[Number(app.globalData.id)].minute,
    _id : app.globalData.zu[Number(app.globalData.id)]._id
      });
    that.setData({
      note: app.globalData.zu[Number(app.globalData.id)].note
    });
    if (app.globalData.zu[Number(app.globalData.id)].weekly[0]==1)
      {
        na = "items[" + 0 + "].name";
        this.setData({
          [na] : "Sun",
        })
      }
    if (app.globalData.zu[Number(app.globalData.id)].weekly[1] == 1) {
      na = "items[" + 1 + "].name";
        this.setData({
          [na]: "Mon",
        })
      }
      if (app.globalData.zu[Number(app.globalData.id)].weekly[2] == 1) {
        [na] = "items[" + 2 + "].name";
        this.setData({
          [na]: 'Tue',
        })
      }
      if (app.globalData.zu[Number(app.globalData.id)].weekly[3] == 1) {
        na = "items[" + 3 + "].name";
        this.setData({
          [na]: 'Wed',
        })
      }
      if (app.globalData.zu[Number(app.globalData.id)].weekly[4] == 1) {
        na = "items[" + 4 + "].name";
        this.setData({
          [na]: 'Thu',
        })
      }
      if (app.globalData.zu[Number(app.globalData.id)].weekly[5] == 1) {
        na = "items[" + 5 + "].name";
        this.setData({
          [na]: "Fri",
        })
      }
      if (app.globalData.zu[Number(app.globalData.id)].weekly[6] == 1) {
        na = "items[" + 6 + "].name";
        this.setData({
          [na]: "Sat",
        })
      }

    },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
  
  
})