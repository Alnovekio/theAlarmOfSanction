var app = getApp();


function _first(callback) {
  wx.request({
    url: 'https://www.ccc425.cn/CostTimeR',
    method: 'GET',
    success: function (res) {
      callback(res);
    },
    fail: function () {
      console.log("failed")
    },
  });
};


Page({

  /**
   * 页面的初始数据
   */
  data: {
    a:[],
    b:[],
    c:"",
    d:"",
    e:"",
    f:"",
    g:"",
    note:"",
    w:[],
    i:"",
    x:0,
    y:0,
    z:0,
    r:0,
    v:0,
    time:[],
    fv:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    _first(function (res){
      app.globalData.time = res.data;
      that.setData({ time: app.globalData.time })
      console.log(that.data.time)
    })
    let na;
    let mg;

    setInterval(function () {
      that.setData({ v: that.data.v + 1 })
    }, 1000) //循环时间 这里是1秒  
    


    //准备随机数
    for(var i=0;i<12;i++){
      na = "a[" + i + "]";
      that.setData({[na]: Math.floor(Math.random() * 100)}); 
    }
    that.setData({ d:that.data.a[0]}) 

    //准备符号
    for(var i=0;i<8;i++){
      var c=Math.floor(Math.random() * 3);
      mg = "b[" + i + "]";
      if(c==0){
        that.setData({ [mg]: "+" }); 
      }
      if(c==1){
        that.setData({ [mg]: "-" }); 
      }
      if(c==2){
        that.setData({ [mg]: "*" }); 
      }
    }

    //标准答案A
    if(that.data.b[0]=="*"){
      that.setData({ d: that.data.a[0] * that.data.a[1] });
      if(that.data.b[1]=="*"){
        that.setData({ d: that.data.d * that.data.a[2] });
      }
      if (that.data.b[1] == "+") {
        that.setData({ d: that.data.d + that.data.a[1] })
      }
      if (that.data.b[1] == "-") {
        that.setData({ d: that.data.d - that.data.a[2] })
      }
    }
    else if(that.data.b[1]=="*")
    {
      that.setData({ d: that.data.a[2] * that.data.a[1] })
      if (that.data.b[0] == "+") {
        that.setData({ d: that.data.d + that.data.a[0] })
      }
      if (that.data.b[0] == "-") {
        that.setData({ d: that.data.a[0] - that.data.d })
      }
    }
    else if(that.data.b[0]=="+")
    {
      that.setData({d:that.data.a[0]+that.data.a[1]})
      if (that.data.b[1] == "+") {
        that.setData({ d: that.data.d + that.data.a[2] })
      }
      if (that.data.b[1] == "-") {
        that.setData({ d: that.data.d - that.data.a[2] })
      }
    }
    else if (that.data.b[0] == "-") {
      that.setData({ d: that.data.a[0] - that.data.a[1] })
      if (that.data.b[1] == "+") {
        that.setData({ d: that.data.d + that.data.a[2] })
      }
      if (that.data.b[1] == "-") {
        that.setData({ d: that.data.d - that.data.a[2] })
      }
    }

    //标准答案B
    if (that.data.b[2] == "*") {
      that.setData({ e: that.data.a[3] * that.data.a[4] })
      if (that.data.b[3] == "*") {
        that.setData({ e: that.data.e * that.data.a[5] })
      }
      if (that.data.b[3] == "+") {
        that.setData({ e: that.data.e + that.data.a[5] })
      }
      if (that.data.b[3] == "-") {
        that.setData({ e: that.data.e - that.data.a[5] })
      }
    }
    else if (that.data.b[3] == "*") {
      that.setData({ e: that.data.a[5] * that.data.a[4] })
      if (that.data.b[2] == "+") {
        that.setData({ e: that.data.e + that.data.a[3] })
      }
      if (that.data.b[2] == "-") {
        that.setData({ e: that.data.a[3] - that.data.e })
      }
    }
    else if (that.data.b[2] == "+") {
      that.setData({ e: that.data.a[3] + that.data.a[4] })
      if (that.data.b[3] == "+") {
        that.setData({ e: that.data.e + that.data.a[5] })
      }
      if (that.data.b[3] == "-") {
        that.setData({ e: that.data.e - that.data.a[5] })
      }
    }
    else if (that.data.b[2] == "-") {
      that.setData({ e: that.data.a[3] - that.data.a[4] })
      if (that.data.b[3] == "+") {
        that.setData({ e: that.data.e + that.data.a[5] })
      }
      if (that.data.b[3] == "-") {
        that.setData({ e: that.data.e - that.data.a[5] })
      }
    }

    //标准答案C
    if (that.data.b[4] == "*") {
      that.setData({ f: that.data.a[6] * that.data.a[7] })
      if (that.data.b[5] == "*") {
        that.setData({ f: that.data.f * that.data.a[8] })
      }
      if (that.data.b[5] == "+") {
        that.setData({ f: that.data.f + that.data.a[8] })
      }
      if (that.data.b[5] == "-") {
        that.setData({ f: that.data.f - that.data.a[8] })
      }
    }
    else if (that.data.b[5] == "*") {
      that.setData({ f: that.data.a[7] * that.data.a[8] })
      if (that.data.b[4] == "+") {
        that.setData({ f: that.data.f + that.data.a[6] })
      }
      if (that.data.b[4] == "-") {
        that.setData({ f: that.data.a[6] - that.data.f })
      }
    }
    else if (that.data.b[4] == "+") {
      that.setData({ f: that.data.a[6] + that.data.a[7] })
      if (that.data.b[5] == "+") {
        that.setData({ f: that.data.f + that.data.a[8] })
      }
      if (that.data.b[5] == "-") {
        that.setData({ f: that.data.f - that.data.a[8] })
      }
    }
    else if (that.data.b[4] == "-") {
      that.setData({ f: that.data.a[6] - that.data.a[7] })
      if (that.data.b[5] == "+") {
        that.setData({ f: that.data.f + that.data.a[8] })
      }
      if (that.data.b[5] == "-") {
        that.setData({ f: that.data.f - that.data.a[8] })
      }
    }

    // //标准答案D
    if (that.data.b[6] == "*") {
      that.setData({ g: that.data.a[9] * that.data.a[10] })
      if (that.data.b[7] == "*") {
        that.setData({ g: that.data.g * that.data.a[11] })
      }
      if (that.data.b[7] == "+") {
        that.setData({ g: that.data.g + that.data.a[11] })
      }
      if (that.data.b[7] == "-") {
        that.setData({ g: that.data.g - that.data.a[11] })
      }
    }
    else if (that.data.b[7] == "*") {
      that.setData({ g: that.data.a[11] * that.data.a[10] })
      if (that.data.b[6] == "+") {
        that.setData({ g: that.data.g + that.data.a[9] })
      }
      if (that.data.b[6] == "-") {
        that.setData({ g: that.data.a[9] - that.data.g })
      }
    }
    else if (that.data.b[6] == "+") {
      that.setData({ g: that.data.a[9] + that.data.a[10] })
      if (that.data.b[7] == "+") {
        that.setData({ g: that.data.g + that.data.a[11] })
      }
      if (that.data.b[7] == "-") {
        that.setData({ g: that.data.g - that.data.a[11] })
      }
    }
    else if (that.data.b[6] == "-") {
      that.setData({ g: that.data.a[9] - that.data.a[10] })
      if (that.data.b[7] == "+") {
        that.setData({ g: that.data.g + that.data.a[11] })
      }
      if (that.data.b[7] == "-") {
        that.setData({ g: that.data.g - that.data.a[11] })
      }
    }

    that.setData({ w: [that.data.d, that.data.e, that.data.f, that.data.g]})
    
    //验证
    // console.log(that.data.a,that.data.b)
    console.log("正确答案为", that.data.d, that.data.e, that.data.f, that.data.g,that.data.w)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },

  copy: function (e) {
    console.log("A")
    var that=this;
    that.setData({i:e.detail.value});
    
  },

  examine:function(){
    var that = this;
    console.log(that.data.time)
    console.log(that.data.v)
    let na;
    console.log(that.data.fv)

    // na = "zu[" + i + "].hour";
    // that.setData({ [na]: that.data.hour });

    if(that.data.x==9){
      
      for (var va = 0; va < 7; va++) {
        that.data.fv = va
        na = "time[" + va + "]";
        if (that.data.fv == 6) {
          that.setData({ [na]: that.data.v })
        }
        else {
          that.setData({ [na]: that.data.time[va + 1] })
        }
      }
      console.log(that.data.time);
      app.globalData.time = that.data.time;
      wx.request({
        url: 'https://www.ccc425.cn/CostTimeW',
        method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
        // header: {}, // 设置请求的 header
        data: {
          time:app.globalData.time
        },
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          console.log("let's see")
          wx.redirectTo({
            url: '../timer/timer',
          })
        },
        fail: function () {
          console.log("we can't see")
        }
      })
    }
    else if(that.data.i==that.data.w[that.data.z]) {
      that.setData({ x: that.data.x + 3 })
      that.setData({ y: that.data.y + 2 })
      that.setData({ z: that.data.z + 1 })
      that.setData({ r: 0 })
      that.setData({ i: "" })
    }
    else {
      that.setData({ r: 1 })
    }
  }
  




  })

  

