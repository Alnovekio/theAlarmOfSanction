function _first(callback) {
  wx.request({
    url: 'https://www.ccc425.cn/NoteList',
    method: 'GET',
    success: function (res) {
      callback(res);
    },
    fail: function () {
      console.log("failed")
    },
  });
};



Page({

  /**
   * 页面的初始数
   */
  data: {
    bar: 0,
    id: '',
    note: '',
    A: [],
    B: [],
    finished: [],
    unfinished: [],
    ph:"",
    newbox: 0
    },

  change: function(){
    if (this.data.bar == 0) this.setData({bar: 1});
    else this.setData({bar: 0});
  },

  newitem: function(e){
    var that=this;
    var timestamp = Date.parse(new Date());
    that.data.id = timestamp;
    that.data.note = e.detail.value.input;
    console.log(that.data.id);
    console.log("当前时间戳为：" + timestamp); 
    wx.request({
      url: 'https://www.ccc425.cn/NewItem',
      method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      data: {
        note:that.data.note,
        id:that.data.id,
      },
      header: {'content-type': 'application/x-www-form-urlencoded'},
      success: function (res) {
        that.ready();
      },
      fail: function () {
        console.log("Failed")
      },
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.ready();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },

  plus: function () {
    if (!this.data.isPopping) {
      this.popp();
      this.setData({
        isPopping: true
      })
    } else if (this.data.isPopping) {
      this.takeback();
      this.setData({
        isPopping: false
      })
    }
  },

  popp: function () {
    var that = this;
    this.setData({newbox: 1});
    var animationPlus = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease-out'
    })

    var animationInput = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease-out'
    })
    animationPlus.rotateZ(180).step();
    animationInput.translate(0, 0).rotateZ(360).opacity(1).step();
    setTimeout(function () {
      that.setData({ ph: "新建日程 请输入日程信息" })
    }, 500);
    this.setData({
      animPlus: animationPlus.export(),
      animInput: animationInput.export(),
    })
  },

  takeback: function () {
    var that = this;
    that.setData({ ph: "" })
    var animationPlus = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease-out'
    })
    var animationInput = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease-out'
    })
    animationPlus.rotateZ(0).step();
    animationInput.translate(0, 0).rotateZ(0).opacity(0).step();
    setTimeout(function(){
      that.setData({newbox: 0})
    }, 500);
    this.setData({
      animPlus: animationPlus.export(),
      animInput: animationInput.export(),
    })
  },




  move:function(e){
    var that = this;
    wx.request({
      url: 'https://www.ccc425.cn/Finish',
      method: 'POST',
      data: {
        id: that.data.A[Number(e.target.id)].id
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log("Got it!");
        that.onLoad();
        },
      fail: function () {
        console.log("Failed")
      }
      
    })
  },

  die: function (e) {
    var that = this;
    console.log("sd4")
    wx.request({
      url: 'https://www.ccc425.cn/NoteRemove',
      method: 'POST',
      data: {
        id: that.data.B[Number(e.target.id)].id
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log("Got it!");
        that.onLoad();
      },
      fail: function () {
        console.log("Failed")
      }
    })
  },


  ready:function (){
    var that = this;
    _first(function (res) {
      console.log(res);
      let na;
      that.setData({A: [], B: []})
      for (var i = 0; i < res.data.unfinished.length; i++) {
        na = "A[" + i + "].note";
        that.setData({ [na]: res.data.unfinished[i].note });
        na = "A[" + i + "].id";
        that.setData({ [na]: res.data.unfinished[i].id });
        var n = that.data.A[i].id ;
        var date = new Date(n);    //年
        na = "A[" + i + "].Y";
        that.setData({ [na]: date.getFullYear() });
        na = "A[" + i + "].M";
        that.setData({ [na]: (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) });
        na = "A[" + i + "].D";
        that.setData({ [na]: date.getDate() < 10 ? '0' + date.getDate() : date.getDate() });
        na = "A[" + i + "].h";
        that.setData({ [na]: date.getHours() });
        na = "A[" + i + "].m";
        that.setData({ [na]: date.getMinutes() });
      }
      for (var i = 0; i < res.data.finished.length; i++) {
        na = "B[" + i + "].note";
        that.setData({ [na]: res.data.finished[i].note });
        na = "B[" + i + "].id";
        that.setData({ [na]: res.data.finished[i].id });
        var n = that.data.B[i].id ;
        var date = new Date(n);    //年  
        na = "B[" + i + "].Y";
        that.setData({ [na]: date.getFullYear() });
        na = "B[" + i + "].M";
        that.setData({ [na]: (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) });
        na = "B[" + i + "].D";
        that.setData({ [na]: date.getDate() < 10 ? '0' + date.getDate() : date.getDate() });
        na = "B[" + i + "].h";
        that.setData({ [na]: date.getHours() });
        na = "B[" + i + "].m";
        that.setData({ [na]: date.getMinutes() });
      }
    })
  }
})


