const requestTask = wx.request({

  url: 'https://api.heclouds.com/devices/503224782/datapoints?datastream_id=Light,Temperature,Humidity&limit=15', //请求的url，把xxxxxxx处换成你自己的deviceID

  header: {

    'content-type': 'application/json',

    'api-key': 'djvbcPv4foXdhZWqQwFQQZNiXgA='  //换成你自己的api-key

  },

  success: function (res) {

    console.log(res)      //打印返回的数据

  },

  fail: function (res) {

    console.log("fail!!!")

  },

  complete: function (res) {

    console.log("end")

  }

})