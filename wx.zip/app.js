//app.js
App({
  globalData:{
    zu:[],
    id:" ",
    time:[],
  },
})
